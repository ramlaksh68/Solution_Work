package com.training.sparkworks;

import static java.lang.System.out;

import java.util.ArrayList;
import java.util.Arrays;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function2;

import com.training.commons.DataSource;
import com.training.commons.SparkConnection;
import com.training.commons.Utilities;

public class SparkOperationClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Logger.getLogger("org").setLevel(Level.ERROR);

		Logger.getLogger("akka").setLevel(Level.ERROR);

		JavaSparkContext sparkContext = SparkConnection.getSparkContext();

		JavaRDD<Integer> collData= DataSource.getCollData();
		System.out.println("Total Number of Records in Collection = "+collData.count());
		
		JavaRDD<String> autoData=sparkContext.textFile("./data/auto-data.csv");
		System.out.println("Total Number of Records in Csv File = "+autoData.count());
		System.out.println("-----------Loading five line from the File-------------");
		Utilities.printStringRDD(autoData, 10);
		
		//autoData.saveAsTextFile("./data/auto-data-uppercase.csv");
		//autoData.map(a->String.join("\t", a.split("   "))).saveAsTextFile("./data/auto-data-ibonseparator.csv");
		
		System.out.println("-----------Tab Separator -------------");
		autoData.map(a->String.join("\t", a.split(","))).take(5).forEach(out::println);
		
		
		System.out.println("-----------Filter Not First-------------");
		
		String header=autoData.first();
		JavaRDD<String> autoWithoutHeader=autoData.filter(a->!a.equals(header));
		Utilities.printStringRDD(autoWithoutHeader, 10);
		
		
		System.out.println("-----------Filter only have toyoto-------------");
		
		JavaRDD<String> autoWithToyoto=autoData.filter(a->a.contains("toyota"));
		Utilities.printStringRDD(autoWithToyoto, 10);
		
		System.out.println("-----------Count Distinct records-------------");
		
		System.out.println("with check dub count "+autoData.distinct().count());
		System.out.println("without check dub count "+autoData.count());
		
		System.out.println("-----------Print Distinct records-------------");
		Utilities.printDistinctRecord(autoData);
		Utilities.printDistinctRecord(collData);
		
		System.out.println("-----------Print No of Words using flatMap-------------");
		out.println("Total word is "+autoWithToyoto.flatMap(a->Arrays.asList(a.split(",")).iterator()).count());
		
		
		System.out.println("-----------Bussionuss Logic using flatMap-------------");
		autoWithToyoto.map(new ClenseRDDCars()).collect().forEach(out::println);
		
		
		JavaRDD<String> words1=sparkContext.parallelize(Arrays.asList("hello","how","are","you"));
		JavaRDD<String> words2=sparkContext.parallelize(Arrays.asList("hello","how","were","yesterday")); 
		
		out.println("-------------Union operation Set-----------------");
		Utilities.printStringRDD(words1.union(words2), 9);
		
		out.println("-------------Intersection operation Set-----------------");
		Utilities.printStringRDD(words1.intersection(words2),9);
		
		out.println("-------------Sum of Number using reduce-----------------");
		out.print("sum of num= "+collData.reduce(Integer::sum));
		
		
		out.println("-------------Sum of MTW IN HighWay using Map-----------------");
		out.print("sum of num= "+autoWithoutHeader.mapToDouble(a->Double.valueOf(""+a.split(",")[10])).stats().mean());

		out.println("-------------Sum of MTW IN HighWay using Reduce-----------------");
		//autoWithoutHeader.reduce(a,=>Double.valueOf(""+a.split(",")[10]));

	}

}
