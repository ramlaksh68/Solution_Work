package com.training.sparkworks;

public class Department {
	private int deptid;
	private String deptnm;
	public int getDeptid() {
		return deptid;
	}
	public void setDeptid(int deptid) {
		this.deptid = deptid;
	}
	public String getDeptnm() {
		return deptnm;
	}
	public void setDeptnm(String deptnm) {
		this.deptnm = deptnm;
	}
	@Override
	public String toString() {
		return "Department [deptid=" + deptid + ", deptnm=" + deptnm + "]";
	}
	public Department(int deptid, String deptnm) {
		super();
		this.deptid = deptid;
		this.deptnm = deptnm;
	}
	public Department() {}
}
