package com.training.sparkworks;

import java.util.Arrays;
import java.util.List;

import org.apache.spark.api.java.function.Function;

public class ClenseRDDCars implements Function<String, String>{

	@Override
	public String call(String v1) throws Exception {
		List<String> numwrd= Arrays.asList("zero","one","two","three","four","five");
		String[] attributeList=v1.split(",");
		attributeList[3]=""+numwrd.indexOf(attributeList[3]);
		return String.join(",", attributeList);
	}

}
