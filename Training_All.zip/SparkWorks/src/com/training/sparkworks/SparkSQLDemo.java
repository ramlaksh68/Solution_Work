package com.training.sparkworks;

import static java.util.stream.Collectors.toList;
import static org.apache.spark.sql.functions.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;

import com.training.commons.SparkConnection;

public class SparkSQLDemo {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Logger.getLogger("org").setLevel(Level.ERROR);

		Logger.getLogger("akka").setLevel(Level.ERROR);

		JavaSparkContext javaSparkContext = SparkConnection.getSparkContext();

		SparkSession sparkSession = SparkConnection.getSparkSession();

		Dataset<Row> dataset = sparkSession.read().json("./data/customerData.json");
		dataset.show(); //// clean table fomat
		dataset.printSchema(); /// show the property datatype
		
		/// data queries 
		System.out.println("Select Query and Where Condition");
		dataset.select("name","salary").where("salary>3000 and gender='male'").show();
		
		System.out.println("Use Group BY and Aggregation");
		dataset.where("salary>3000").groupBy("gender").agg(avg("salary"),sum("salary"),max("age"),count("gender")).show();
		
		 ///   try with bean class -------------
		
		List<Department> deptList= Stream.of(new Department(100, "Develpement"),new Department(200, "Testing")).collect(toList());
		
		Dataset<Row> deptDataset=sparkSession.createDataFrame(deptList, Department.class);
		System.out.println("Department Contents are");
		deptDataset.show();
		
		System.out.println("Join Employee with Department without field matching");
		deptDataset.join(dataset).show();
		// deptDataset.join(dataset,col("deptid").equalTo("yourTableColumn")).show(); 
		
		System.out.println("Join Employee with Department with filed match");
		Dataset<Row> dptempSet=deptDataset.join(dataset,"deptid");dptempSet.show();
		// deptDataset.join(dataset,col("deptid").equalTo(col("yourTableColumn"))).show(); 
		
		
		System.out.println("Join Employee with Department with filed match Doing Aggregation and Groupby");
		dptempSet.where("age>30").groupBy("deptnm").agg(sum("salary"),max("age")).show();
		
		System.out.println("Load data from CSV without header");
		Dataset<Row> autoDataWOHeader=sparkSession.read().csv("./data/auto-data.csv");
		autoDataWOHeader.show(5);
	
		System.out.println("Load data from CSV with header");
		Dataset<Row> autoDataWHeader=sparkSession.read().option("header", "true").csv("./data/auto-data.csv");
		autoDataWHeader.show(5);

		
		System.out.println("Creating RDD with row Objects");
		List<Row> rowList=Stream.of(RowFactory.create(1,"India","Chennai"), RowFactory.create(1,"Malaysia","Bennong"),
				RowFactory.create(1,"China","Something"),RowFactory.create(1,"Dubai","Kalifa")).collect(toList());
		
		JavaRDD<Row> rowRdd	= javaSparkContext.parallelize(rowList);
		
		StructType schema = DataTypes.createStructType(new StructField[]{DataTypes.createStructField("id", DataTypes.IntegerType, false),
				DataTypes.createStructField("country", DataTypes.StringType, true),
				DataTypes.createStructField("city", DataTypes.StringType, true)
		});
		
		Dataset<Row> tempDataFields=sparkSession.createDataFrame(rowRdd, schema);
		tempDataFields.show();
		tempDataFields.printSchema();
		
		
		
		autoDataWHeader.createOrReplaceTempView("autos");
		System.out.println("Temp Table Contents");
		
		sparkSession.sql("select * from autos where hp>200").show();
		
		sparkSession.sql("select make,max(rpm) from autos group by make order by 2 desc").show();
		

		Map<String,String> jdbcConnectParams = new HashMap<String,String>();
		 jdbcConnectParams.put("url", "jdbc:mysql://localhost:3306/exdb");
		 jdbcConnectParams.put("driver", "com.mysql.jdbc.Driver");
		 jdbcConnectParams.put("dbtable", "employee");
		 jdbcConnectParams.put("user", "root");
		 jdbcConnectParams.put("password", "root@123");
		 
		 System.out.println("create a datafram from a db table (employee)");
		 Dataset<Row> sqlDataFields = sparkSession.read().format("jdbc").options(jdbcConnectParams).load();
		 sqlDataFields.show();
	}
}
