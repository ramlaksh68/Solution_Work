package com.training.commons;

import java.util.Arrays;
import java.util.List;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;

public class DataSource {
	public static JavaRDD<Integer> getCollData(){
		JavaSparkContext sparkContext=SparkConnection.getSparkContext();
		
		List<Integer> data= Arrays.asList(2,3,2,56,67,56,68,78,34);
		
		JavaRDD<Integer> collData= sparkContext.parallelize(data);
		
		collData.cache();
		
		return collData;
	}
}
