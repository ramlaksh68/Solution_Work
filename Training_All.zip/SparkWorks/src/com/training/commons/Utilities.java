package com.training.commons;
import static java.lang.System.*;
import org.apache.spark.api.java.JavaRDD;

public class Utilities {
	public static void printStringRDD(JavaRDD<String> stringrdd,int limit) {
		stringrdd.take(limit).forEach(out::println);
	}
	public static void printDistinctRecord(JavaRDD stringrdd) {
		stringrdd.distinct().collect().forEach(out::println);
	}
	public static void hold() {
		while(true) {
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
	}
}
