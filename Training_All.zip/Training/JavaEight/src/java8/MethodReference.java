package java8;

import java.util.ArrayList;
import java.util.function.BiFunction;
import java.util.function.Function;

interface Messageable{
	MethodReference getCessage();
}

public class MethodReference {
	
	public  void Runner() {
		System.out.println("Runner of Thread");
	}
	public MethodReference(String msg1,String msg2) {
		
	}
	public MethodReference() {
		
	}
	public static void main(String[] args) {
		
		//// Constructor Refernce
		Messageable hello = MethodReference::new;
		hello.getCessage();
		
				
		////////if the constructor have any arguments for User Defined Classes
		BiFunction<String,String,MethodReference> fun=MethodReference::new;
		fun.apply("ramu","laksh");
		
		
		////////if the constructor have any arguments for PreDefined Classes
		Function<Integer,ArrayList> arylist=ArrayList::new;
		arylist.apply(10);
		
		
		////// Method reference 
		Thread thread=new Thread(()->System.out.println("HI THREAD"));
		Thread thread1=new Thread(new MethodReference()::Runner);
		thread1.start();
		
		
		
		
		
	}
}






