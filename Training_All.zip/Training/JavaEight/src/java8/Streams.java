package java8;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;
class Product{  
    int id;  
    String name;  
    float price;  
    public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public Product(int id, String name, float price) {  
        this.id = id;  
        this.name = name;  
        this.price = price;  
    }
	public Product() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", price=" + price + "]";
	}  

public boolean isAvgSalery() {
	  return this.price>25000;
}
}  
public class Streams {
public static void main(String[] args) {
	List list=Arrays.asList(1,2,3,4,5,6,7);
	list.stream().filter(dt->(int)dt>=5).forEach(System.out::print);
	
	///////Streaming Functionalities
	   List<Product> productsList = new ArrayList<Product>();  
        //Adding Products  
        productsList.add(new Product(1,"HP Laptop",25000f));  
        productsList.add(new Product(2,"Dell Laptop",30000f));  
        productsList.add(new Product(3,"Lenevo Laptop",28000f));  
        productsList.add(new Product(4,"Sony Laptop",28000f));  
        productsList.add(new Product(5,"Apple Laptop",90000f));  
      
        ///////Return Whole Object By Filters
        
        productsList.stream() .filter(p -> p.price > 30000)
       .forEach((dt)->System.out.println(dt));
        
        /////////Return Particular Column By MAP
        
        productsList.stream() .filter(p -> p.price > 30000).map(dt->{
        	return dt.name+"-"+dt.price;
        })
        .forEach(System.out::println);
        
        ///////// Reutrn Custom Object by Collectors
        
       Map hm= productsList.stream() .filter(p -> p.price > 30000).collect(Collectors.toMap(obj->obj.id,obj->obj.name));
       System.out.println(hm);
        
///////// Reutrn Custom Object by Reduce
       
   //    productsList.stream() .filter(p -> p.price > 30000).reduce((old,nw)->old.id+nw.id)     ;   
       
       
       
       ///// Once the Stream closed We cannot Reuse it Again
       
       String[] data= {"hi","dr","how","hi"};
       List li=Arrays.stream(data).distinct().collect(Collectors.toList());li.forEach(System.out::println);
    //   Stream of=Stream.of("hi");

      Stream<String> li2=Arrays.stream(data).distinct();
      System.out.println(li2.count());;
      System.out.println(li2.count());;
      
     }




}
