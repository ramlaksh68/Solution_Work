package java8;

import java.util.Arrays;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class StreamCreation {
	
	public static void main(String[] args) {
		Stream.of(1,2,3,45,6,7,9,"ds",new int[] {13,25,37}).forEach(System.out::println);
		System.out.println("------------------------------");
		Arrays.stream(new int[] {13,25,37,24,56,67,78},2,6).forEach(System.out::println);
		System.out.println("------------------------------");
		IntStream.range(1,10).forEach(System.out::println);
		System.out.println("------------------------------");
		System.out.println(IntStream.rangeClosed(0,100).reduce(0,Integer::sum)); 
		System.out.println("------------------------------");
		System.out.println(IntStream.range(0,100).reduce(0,Integer::sum)); 
		System.out.println("------------------------------");
		System.out.println(Stream.iterate(1,i->i+1).limit(100).reduce(0,Integer::sum)); 
		System.out.println("------------------------------");
		Stream.iterate(1,i->i+1).limit(100).forEach(System.out::println);
	}
}
