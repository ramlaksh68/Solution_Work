package java8;

interface MyInterface{  
   default void newMethod(){  
        System.out.println("Newly added default method");  
    }  
    static void anotherNewMethod(){
    	System.out.println("Newly added static method");
    }
    void existingMethod(String str);  
}  
public class DefaultAndStatic implements MyInterface{ 
	  public void existingMethod(String str){           
        System.out.println("String is: "+str);  
    }  
    public static void main(String[] args) {  
    	DefaultAndStatic obj = new DefaultAndStatic();
       obj.newMethod();     
       MyInterface.anotherNewMethod();
        obj.existingMethod("Java 8 is easy to learn"); 
        
  
    }  
}