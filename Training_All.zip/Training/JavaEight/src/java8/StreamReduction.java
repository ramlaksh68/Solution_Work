package java8;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class StreamReduction {

		public static void main(String[] args) {
			List<Integer> list=Arrays.asList(1,2,3,4);
			Integer in1=list.stream().reduce((a,b)->a+b).get();
			System.out.println("One Arg = > "+in1);
			Integer in2=list.stream().reduce(2,(a,b)->a+b);
			System.out.println("Two Arg In Stream = > "+in2);
			Integer in4=list.parallelStream().reduce(2,(a,b)->a+b);
			System.out.println("Two Arg In Parallel Stream = > "+in4);
			Integer in3=list.parallelStream().reduce(2,(a,b)->a+b,(a,b)->{
				System.out.println("Combiner Calling ");
				return a+b;
			});
			System.out.println("Three Arg = > "+in3);
			
			  List<Product> productsList = new ArrayList<Product>();  
		        //Adding Products  
		        productsList.add(new Product(1,"HP Laptop",25000f));  
		        productsList.add(new Product(2,"Dell Laptop",30000f));  
		        productsList.add(new Product(3,"HP Laptop",28000f));  
		        productsList.add(new Product(4,"HP Laptop",28000f));  
		        productsList.add(new Product(5,"Apple Laptop",90000f));  
		 
		        /////// getting Max Price Product
		        Product min=  productsList.stream().collect(Collectors.maxBy((a,b)->{
		    	 return (""+a.getPrice()).compareTo(""+b.getPrice());
		     })).get(); 
		        System.out.println(min+"---");
		        /////// Grouping the Product List By Price of Product
		        
		       Map<Object, List<Product>> groupByPrice=  productsList.stream().collect(Collectors.groupingBy(Product::isAvgSalery)); 
		groupByPrice.forEach((key,val)->{
			   System.out.println(key+ "-"+val);
		});
		 /////// Partioning the Product List By Price of Product
		System.out.println("--------------------------");
		 Map<Boolean, List<Product>> partionByPrice=  productsList.stream().collect(Collectors.partitioningBy(Product::isAvgSalery)); 
		 partionByPrice.forEach((key,val)->{
				   System.out.println(key+ "-"+val);
			});
		
		 /////// Counting With Aggregation the Product List By Price of Product
		System.out.println("--------------------------");
		 Map<Object,Long> countAndGroupByPrice=  productsList.stream().collect(Collectors.groupingBy(Product::getPrice,Collectors.counting())); 
		 countAndGroupByPrice.forEach((key,val)->{
				   System.out.println(key+ "-"+val);
			});
		
		
		 /////// First partioning By Price After Group By name
			System.out.println("--------------------------");
			 Map<Boolean, Map<String, Long>> partByPriceAndGrupByName=  productsList.stream().
					 collect(Collectors.partitioningBy(Product::isAvgSalery,
							 Collectors.groupingBy(Product::getName,Collectors.counting()))); 
			 partByPriceAndGrupByName.forEach((key,val)->{
					   System.out.println(key+ "-"+val);
				});
			 
			 
			 
			 /////// First Group By name After partioning By Price  
				System.out.println("--------------------------");
				 Map<String, Map<Boolean, Long>> GrupByNameAndpartByPrice=  productsList.stream().
						 collect(Collectors.groupingBy(Product::getName,
								 Collectors.partitioningBy(Product::isAvgSalery,Collectors.counting()))); 
				 GrupByNameAndpartByPrice.forEach((key,val)->{
						   System.out.println(key+ "-"+val);
					});
			 
			 
			 
			 
			}
		
		
		
		
}
