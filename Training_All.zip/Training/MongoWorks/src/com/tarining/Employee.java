package com.tarining;

import java.io.Serializable;

import com.mongodb.BasicDBObject;

public class Employee  extends BasicDBObject implements Serializable{

		private int empid;
		private String empnm;
		private String empemail;
		private Double empsalary;
		public int getEmpid() {
			return empid;
		}
		public void setEmpid(int empid) {
			this.empid = empid;
		}
		public String getEmpnm() {
			return empnm;
		}
		public void setEmpnm(String empnm) {
			this.empnm = empnm;
		}
		public Double getEmpsalary() {
			return empsalary;
		}
		public void setEmpsalary(Double empsalary) {
			this.empsalary = empsalary;
		}
		public Employee() {}
		public Employee(int empid, String empnm, Double empsalary,String empemail) {
			super();
			this.empid = empid;
			this.empnm = empnm;
			this.empsalary = empsalary;
			this.empemail = empemail;
			this.put("empid", empid);
			this.put("empnm", empnm);
			this.put("empemail", empemail);
			this.put("empsalary", empsalary);
		}
		public String getEmpemail() {
			return empemail;
		}
		public void setEmpemail(String empemail) {
			this.empemail = empemail;
		}
		
}
