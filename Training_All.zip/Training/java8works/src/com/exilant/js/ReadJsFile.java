package com.exilant.js;

import java.io.FileNotFoundException;
import java.io.FileReader;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

public class ReadJsFile {
	public static void main(String[] args) throws FileNotFoundException, ScriptException {
		ScriptEngineManager scriptMger=new ScriptEngineManager();
		ScriptEngine script=scriptMger.getEngineByName("nashorn");
		 script.eval(new FileReader("resources/external.js"));
		 script.eval("fromJavatoJS()");
	}
}
