package com.exilant.day3;

import java.util.ArrayList;
import java.util.List;

class Multiple<A, B, C> {

	private A _aa;
	private B _bb;
	private C _cc;
	public A get_aa() {
		return _aa;
	}
	public void set_aa(A _aa) {
		this._aa = _aa;
	}
	public B get_bb() {
		return _bb;
	}
	public void set_bb(B _bb) {
		this._bb = _bb;
	}
	public C get_cc() {
		return _cc;
	}
	public void set_cc(C _cc) {
		this._cc = _cc;
	}
	@Override
	public String toString() {
		return "Multiple [_aa=" + _aa + ", _bb=" + _bb + ", _cc=" + _cc + "]";
	}
	public Multiple() {}
	public Multiple(A _aa, B _bb, C _cc) {
		super();
		this._aa = _aa;
		this._bb = _bb;
		this._cc = _cc;
	}
	

}

 
 
 
 
 
 public class TupleEx01{
	 
	 
	 
	 public static Multiple<Integer,String,Boolean> newtuple(){
		 return new Multiple(10,"Ramu",true);
	 }
	 
	 	 
	 public static void main(String[] args) {
		 Multiple<Integer,String,Boolean> tuple1=newtuple();
		 System.out.println("Interger : "+tuple1.get_aa());
		 System.out.println("String : "+tuple1.get_bb());
		 System.out.println("Boolean : "+tuple1.get_cc());
		 
		 List<Multiple<Integer,String,Boolean>> mylist=new ArrayList<>();
		 
		 
	}
 }