package com.exilant.day1;



//this program to show tgke simple working o f functional interface
@FunctionalInterface
interface MathOperation{
	public int opertaion(int num1,int num2);
}

public class LamdaEx03 {
	
	public static int operation(int num1,int num2,MathOperation opr) {
		return opr.opertaion(num1, num2);
	}
	
	public static void main(String[] args) {
		
		MathOperation sum=(num1,num2)->num1+num2;
		MathOperation diff=(num1,num2)->num1-num2;
		System.out.println(operation(10, 20, sum));
		System.out.println(operation(30, 20, diff));
	} 

}
