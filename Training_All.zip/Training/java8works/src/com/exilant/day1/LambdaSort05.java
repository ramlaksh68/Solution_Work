package com.exilant.day1;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class LambdaSort05 {

	public static void main(String[] args) {
		List<Customer> customers = Arrays.asList(new Customer(101, "Ramu", 6000d, "Engineer"),
				new Customer(104, "Pooja", 6500d, "Developer"), new Customer(102, "Allahraka", 7500d, "Lead"),
				new Customer(107, "Anuj", 5600d, "Engineer"), new Customer(103, "Siva", 4000d, "Developer"));
		
		System.out.println("---------way one BY ID------------");
		
		Comparator<Customer> sort= (obj1,obj2)->(""+obj1.getCustomerId()).compareTo(""+obj2.getCustomerId());
		Collections.sort(customers, sort);
		customers.forEach(System.out::println);
		
		
		System.out.println("---------way one BY ID DEsc------------");
		Collections.sort(customers, sort.reversed());
		customers.forEach(System.out::println);
		
		
		System.out.println("---------way two BY NAME------------");
		customers.sort((obj1,obj2)->(""+obj1.getCustomerName()).compareTo(""+obj2.getCustomerName()));
		customers.forEach(System.out::println);
		
		
		Comparator<Customer> cust=Comparator.comparing(Customer::getCustomerName).thenComparing(Customer::getCustomerId);
		
		
		
	}
}
