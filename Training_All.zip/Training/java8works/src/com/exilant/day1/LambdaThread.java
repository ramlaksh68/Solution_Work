package com.exilant.day1;

public class LambdaThread {
	public static void main(String[] args) {
		///// Using Anonums Class
		Thread thread1 = new Thread(new Runnable() {

			@Override
			public void run() {
				System.out.println("Heelo");
			}
		});
		///// Using Lambda Expression
		Thread thread2 = new Thread(() -> System.out.println("Heelo"));
		thread1.start();
		thread2.start();
	}
}
