package com.exilant.day1;

public class Customer {
	private int customerId;
	private String customerName;
	private Double customerNamePurchases;
	private String designation;

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Double getCustomerNamePurchases() {
		return customerNamePurchases;
	}

	public void setCustomerNamePurchases(Double customerNamePurchases) {
		this.customerNamePurchases = customerNamePurchases;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", customerNamePurchases="
				+ customerNamePurchases + ", designation=" + designation + "]";
	}

	public Customer() {};
	
	public Customer(int customerId, String customerName, Double customerNamePurchases, String designation) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerNamePurchases = customerNamePurchases;
		this.designation = designation;
	}
	
	public  boolean isAbove5k() {
		return this.customerNamePurchases>5000;
	}
	
	
}
