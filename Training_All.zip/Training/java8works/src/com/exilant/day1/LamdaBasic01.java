package com.exilant.day1;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;
import java.util.stream.Stream;

public class LamdaBasic01 {

	public static void main(String[] args) {
		List<Integer> numbers = Arrays.asList(10, 20, 30, 40, 50);

		// till jdk 1.5
		System.out.println("-----------before jdk 1.5 ------------------");

		for (int i = 0; i < numbers.size(); i++) {
			System.out.println(numbers.get(i));
		}

		// till jdk 1.7
		System.out.println("-----------before jdk 1.7 ------------------");

		for (Integer number : numbers) {
			System.out.println(number);
		}

		// now jdk 1.8
		System.out.println("-----------Now jdk 1.8 with Lambda Expression ------------------");

		numbers.forEach((number) -> {
			System.out.println(number);
		});

		// now jdk 1.8 begind the screen
		System.out.println("-----------Now jdk 1.8 with Lambda Expression  begind the screen ------------------");

		numbers.forEach(new Consumer<Integer>() {
			@Override
			public void accept(Integer t) {
				System.out.println(t);
			}
		});

		// now jdk 1.8 Method Refrence
		System.out.println("-----------Now jdk 1.8 with Lambda Expression & Method Reference ------------------");

		numbers.forEach(System.out::println);
		
		System.out.println("-----------Now jdk 1.8 with Stream Manipulation ------------------");
		
		Integer sum = numbers.stream().map(no->no*2).reduce(Integer::sum).get();

		System.out.println("Sum of  Numbers = " + sum);

	}

}
