package com.exilant.day2;

public interface IEmployee {
	void salary();

	default void noOfHours() {
		System.out.println("Every Employee Has to Work 8 Hours");
	}
	
	static void commonUtility() {
		System.out.println("Comman Utility");
	}
}
