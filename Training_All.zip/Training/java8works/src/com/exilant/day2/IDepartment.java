package com.exilant.day2;

public interface IDepartment {
 void workLocation();
 
 default void noOfHours() {
	 System.out.println("THe prohject to work only til 6 pm");
 }
}
