package com.exilant.day2;
import static java.lang.System.*;
import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

public class PredicateExample {
public static void main(String[] args) {
	Predicate<Integer> greaterThanEq=(no)->no>=4;
	Predicate<Integer> lessThanEq=(no)->no<=7;
	List<Integer> numbers=Arrays.asList(1,2,3,4,5,6,7,8,9);
	System.out.println("-------- Greater than eq 4 ---------");
	numbers.stream().filter(greaterThanEq).forEach(out::println);
	
	System.out.println("--------  Less than eq 7  ---------");
	numbers.stream().filter(lessThanEq).forEach(out::println);
	
	System.out.println("--------- Greater than eq 4  &&  Less than eq 7  --------");
	numbers.stream().filter(lessThanEq. and(greaterThanEq)).forEach(out::println);
	
	System.out.println("--------- Greater than eq 4  ||  Less than eq 7  --------");
	numbers.stream().filter(greaterThanEq.or(lessThanEq)).forEach(out::println);
	
	
	
	
	
	
	
	
}
}
