package com.exilant.day2;

public class StringComparator {
	public static void main(String[] args) {
		
		StringCompare lengthCompare=(text1,text2)->text1.length()>text2.length()?text1:text2;
		
		
		StringPerformer perform=new StringPerformer();
		
		System.out.println(perform.stringPerfomer("RAMU.M", "LAXSH",lengthCompare));
		
		System.out.println(lengthCompare.stringCompare("RAMU", "LAXSH"));
	}
}
