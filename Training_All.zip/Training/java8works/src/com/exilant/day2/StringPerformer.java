package com.exilant.day2;

public class StringPerformer {
	String stringPerfomer(String text1,String text2,StringCompare strComp) {
		return strComp.stringCompare(text1, text2);
	}
}
