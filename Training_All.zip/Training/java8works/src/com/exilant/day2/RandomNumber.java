package com.exilant.day2;

import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.IntStream;

public class RandomNumber {
public static void main(String[] args) {
	
	System.out.println("_______Without Using Random Class__________");
	int randomNumber=ThreadLocalRandom.current().nextInt(100, 200);
	System.out.println(randomNumber);
	
	System.out.println("_______Using Random Class__________");
	
	Random random =new Random();
	random.ints(10,200,400).sorted().forEach(System.out::println);
	
	System.out.println("_______Using Java 8 Class__________");
	
	IntStream.rangeClosed(1, 100).forEach(System.out::println);
	
}
}
