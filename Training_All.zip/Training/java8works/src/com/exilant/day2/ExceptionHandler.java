package com.exilant.day2;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class ExceptionHandler {

	public static void main(String[] args) throws FileNotFoundException, IOException {
		File file=new File("test.txt");
		fileWritter(file);
		fileReader(file);
	}

	public static void fileWritter(File file) throws IOException {
		try (FileWriter filewriter=new FileWriter(file)){
			filewriter.write("Hello .....!! How are you...?");
			System.out.println("Write Complted");
			}
			
	}
	
	public static void fileReader(File file) throws FileNotFoundException, IOException {
		try (FileReader fr=new FileReader(file)){
			System.out.println("reading");
			BufferedReader br=new BufferedReader(fr);
			System.out.println(br.readLine());
			  
			}
			
	}
	
}
