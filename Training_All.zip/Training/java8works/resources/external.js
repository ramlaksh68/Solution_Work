/**
 * 
 */



function fromJavatoJS(){
	print("HI.....JS")
}