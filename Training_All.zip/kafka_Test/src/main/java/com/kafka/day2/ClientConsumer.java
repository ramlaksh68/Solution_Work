package com.kafka.day2;

import kafka.consumer.Consumer;

public class ClientConsumer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Consumers consumer=new Consumers(KafkaProperties.TOPICS2, true);
		consumer.start();
	}

}
