package com.kafka.day2;

import java.util.Properties;
import java.util.concurrent.ExecutionException;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.IntegerSerializer;
import org.apache.kafka.common.serialization.StringSerializer;

public class Producers extends Thread{

	private final KafkaProducer<Integer,String> producer;
	private String topic;
	private Boolean isAsync;
	private Boolean interept;
	private String name;
	@Override
	public void run() {
		int messageNo=1;
		while(!interept) {
			String message="Message From Producer "+this.name +" Count : "+messageNo;
			ProducerRecord<Integer, String> producerRecord=new ProducerRecord<Integer, String>(this.topic, messageNo,message);
			if(isAsync) {
				long startTime = System.currentTimeMillis();
				producer.send(producerRecord,new ProducerMessageCallable(startTime, messageNo, message));
			}
			else {
				try {
					producer.send(producerRecord).get();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
			}
			messageNo++;
		}
	}
	public Producers( String topic,Boolean isAsync,String name) {
		super();
		this.topic=topic;
		this.isAsync=isAsync;
		this.interept=false;
		this.name=name;
		Properties properties =new Properties();
		properties.setProperty("bootstrap.servers",KafkaProperties.KAFKA_SERVER_URL+":"+KafkaProperties.KAFKA_SERVER_PORT);
		properties.setProperty("client.id", KafkaProperties.PRODUCER_CLIENT_ID);
		properties.setProperty("key.serializer", IntegerSerializer.class.getName());
		properties.setProperty("value.serializer", StringSerializer.class.getName());
		this.producer = new KafkaProducer<Integer, String>(properties);
	}
	
	
	
	public void setInterept(Boolean interept) {
		this.interept = interept;
	}
	
	
	
	
}
