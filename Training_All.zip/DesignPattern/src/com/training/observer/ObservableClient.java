package com.training.observer;

import java.util.stream.Stream;

public class ObservableClient {

	public static void main(String[] args) {
		// OnePlus User Observer
		IObservable observable = new OnePlus6T();

		Stream.of(new User(observable, "ramu"), new User(observable, "lax"), new User(observable, "siva"),
				new User(observable, "raja"), new User(observable, "kumar"), new User(observable, "muruga"))
				.forEach(observable::addUser);

		((OnePlus6T) observable).setArrived(true);
		
		System.out.println("-------------- *** ----------------------");
		
		// Apple User Observer
		IObservable appleobservable = new Apple();

		Stream.of(new User(appleobservable, "ramu"), new User(appleobservable, "lax"),
				new User(appleobservable, "siva"), new User(appleobservable, "raja"),
				new User(appleobservable, "kumar"), new User(appleobservable, "muruga"))
				.forEach(appleobservable::addUser);

		((Apple) appleobservable).setArrived(true);
	}

}
