package com.training.singleton;

import java.io.Serializable;

//the single ton says there should be only one object
//to do we will have the variables as static so that you can have only one 
//one reference ,in singleton we can have two types
//1.eager instance 2.lazy instance


public class Singleton implements Serializable{

	private static final Singleton instance=new Singleton();
			
	//shall we  
	private Singleton() {
		System.out.println("the constructor is called...");
	}

	public static Singleton getInstance() {
		return instance;
	}
	
	protected Object readResolve(){
		return getInstance();
	}
}
