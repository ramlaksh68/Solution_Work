package com.training.singleton;

//lazy singleton



class Company{
	
	private Company() {
		System.out.println("the constructor is called...");
	}
	
	public static Company getInstance(Company com) {
		return com==null?new Company():com;
	}	
}


class Emp{
	int empid;
	String empname;
	Company company;
	public Emp(int empid, String empname, Company company) {
		super();
		this.empid = empid;
		this.empname = empname;
		this.company = company;
	}
	
}


public class SingletonClient02 {
	public static void main(String[] args) {
		//you cannot create an instance of variable
		//Company cmp=new Company();
		Company cmp=null;
		Company cmps=Company.getInstance(cmp);
		
		Emp em2=new Emp(12,"ABC",cmps);
		Emp em1=new Emp(125,"CBD",cmps);
	}

}
