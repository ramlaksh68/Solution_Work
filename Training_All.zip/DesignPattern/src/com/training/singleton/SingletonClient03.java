package com.training.singleton;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

//p[rogram to access singleton throught reflection

public class SingletonClient03 {

	public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		Singleton sngle=Singleton.getInstance();
		Singleton sngle1=null;
		Singleton sngle2=null;
		
		Constructor con=Singleton.class.getDeclaredConstructors()[0];
		con.setAccessible(true);
		sngle1=(Singleton) con.newInstance();
		sngle2=(Singleton) con.newInstance();
		System.out.println(sngle.hashCode()+"\n"+sngle1.hashCode()+"\n"+sngle2.hashCode());
	}
}
