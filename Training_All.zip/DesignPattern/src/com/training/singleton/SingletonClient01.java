package com.training.singleton;

///this class showing eager singleton

public class SingletonClient01 {

	public static void main(String[] args) {
			
		Singleton single=Singleton.getInstance();
		System.out.println(single.hashCode());
	
	
		Singleton single1=Singleton.getInstance();
		System.out.println(single1.hashCode());
		
		Singleton single2=Singleton.getInstance();
		System.out.println(single2.hashCode());
		
		
		
	}

}
