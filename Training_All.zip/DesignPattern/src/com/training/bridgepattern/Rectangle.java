package com.training.bridgepattern;

public class Rectangle extends Shape {
	
	Rectangle(IColor color){
		super(color);
	}
	
	@Override
	public void applyColor() {
		System.out.println("Color is applied here with : "+getColor());
		getColor().applyColor();
	}

}
