package com.training.bridgepattern;

public class Triangle extends Shape  {

	public Triangle(IColor color) {
		super(color);
	}
	@Override
	public void applyColor() {
	System.out.println("Color is applied here with : "+getColor());
	getColor().applyColor();
	}

}
