package com.training.filter;

import java.util.List;

import com.training.statergy.Person;

public class AndCriteria implements ICriteria {
	private ICriteria firstCriteria;
	private ICriteria secCriteria;
	public AndCriteria(ICriteria firstCriteria, ICriteria secCriteria) {
		super();
		this.firstCriteria = firstCriteria;
		this.secCriteria = secCriteria;
	}

	@Override
	public List<Person> meetCriteria(List<Person> person) {
		List<Person> fist=firstCriteria.meetCriteria(person);
		return secCriteria.meetCriteria(fist);
	}

}
