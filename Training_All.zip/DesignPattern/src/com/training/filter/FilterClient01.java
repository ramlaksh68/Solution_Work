package com.training.filter;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.training.statergy.Person;

public class FilterClient01 {
	public static void main(String[] args) {
		List<Person> personList=Arrays.asList(
				new Person("ramu","male","unmarried"),
				new Person("raja","male","unmarried"),
				new Person("laxmi","female","married"),
				new Person("siva","male","unmarried"),
				new Person("jeyanthi","female","unmarried"),
				new Person("mala","female","married"),
				new Person("murugappan","male","married"),
				new Person("siva","male","married")
				);
		
		System.out.println("Filter Only Male");
		
		ICriteria maleList=new Male();
		List<Person> male=maleList.meetCriteria(personList);
		male.forEach(System.out::println);
		
		System.out.println("Filter Only FeMale");
		
		ICriteria femaleList=new FeMale();
		List<Person> female=femaleList.meetCriteria(personList);
		female.forEach(System.out::println);
		
		System.out.println("Filter Only Married");
		
		ICriteria mriedList=new Martial();
		List<Person> married=mriedList.meetCriteria(personList);
		married.forEach(System.out::println);
		
		System.out.println("Filter Only UNMarried");
		
		ICriteria unmriedList=new UnMarried();
		List<Person> unmaried=unmriedList.meetCriteria(personList);
		 unmaried.forEach(System.out::println);
		
		
		System.out.println("----Filter Only Married & MAle---");
		ICriteria andList=new AndCriteria(maleList,mriedList);
		andList.meetCriteria(personList).forEach(System.out::println);
		
		System.out.println("---Filter Only Married OR MAle---");
		ICriteria orList=new OrCritria(maleList,mriedList);
		orList.meetCriteria(personList).forEach(System.out::println);
}
}
