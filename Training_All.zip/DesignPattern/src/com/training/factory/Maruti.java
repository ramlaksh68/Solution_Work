package com.training.factory;

public class Maruti extends Car{
	public Maruti() {
		System.out.println("Maruti Created");
	}
	
	public void drive()
	{
		System.out.println("driving Maruti");
	}
	
}
