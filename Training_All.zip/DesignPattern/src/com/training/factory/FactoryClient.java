package com.training.factory;

public class FactoryClient {

	public static void main(String[] args) {
		Car bmw=Car.getCar(CarName.BMW);
		bmw.drive();
		Car maruti=Car.getCar(CarName.MARUTI);
		maruti.drive();
	}

}
