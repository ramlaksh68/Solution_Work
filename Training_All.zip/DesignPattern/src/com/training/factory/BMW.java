package com.training.factory;

public class BMW extends Car{

	public BMW() {
		System.out.println("BMW Created");
	}
	
	public void drive()
	{
		System.out.println("driving BMW");
	}
	
}
