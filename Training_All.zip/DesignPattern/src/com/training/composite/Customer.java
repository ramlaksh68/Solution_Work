package com.training.composite;

import java.util.ArrayList;
import java.util.List;

public class Customer {

	private int customerid;
	private String customername;
	private List<Customer> refrence;
	public int getCustomerid() {
		return customerid;
	}
	public void setCustomerid(int customerid) {
		this.customerid = customerid;
	}
	public String getCustomername() {
		return customername;
	}
	public void setCustomername(String customername) {
		this.customername = customername;
	}
	public List<Customer> getRefrence() {
		return refrence;
	}
	public void setRefrence(List<Customer> refrence) {
		this.refrence = refrence;
	}
	public Customer(int customerid, String customername) {
		super();
		this.customerid = customerid;
		this.customername = customername;
		refrence=new ArrayList<>();
	}
	@Override
	public String toString() {
		return "Customer [customerid=" + customerid + ", customername=" + customername + ", refrence=" + refrence + "]";
	}
	public void addRefernce(Customer cus) {
		this.refrence.add(cus);
	}
	public void removeRefernce(Customer cus) {
		this.refrence.remove(cus);
	}
}
