package com.training.mvc;

public class EmplyeeController {
	private Employee model;
	private Views view;
	public EmplyeeController() {}
	public EmplyeeController(Employee model, Views view) {
		super();
		this.model = model;
		this.view = view;
	}
	public Employee getModel() {
		return model;
	}
	public void setModel(Employee model) {
		this.model = model;
	}
	public Views getView() {
		return view;
	}
	public void setView(Views view) {
		this.view = view;
	}
	public void updateView(String string) {
		System.out.println("Its printing ....."+string+".......View");
		view.printEmployee(model);
	}
	
	
}
