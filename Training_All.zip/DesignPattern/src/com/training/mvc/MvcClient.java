package com.training.mvc;

public class MvcClient {
public static void main(String[] args) {
	Employee emp=new Employee(101,"Ramu");
	
	Views star=new StarView();
	
	EmplyeeController controller=new EmplyeeController(emp,star);
	controller.updateView("star");
	
	
	Views dash=new DashView();
	
	EmplyeeController controller1=new EmplyeeController(emp,dash);
	controller1.updateView("dash");
}
}
