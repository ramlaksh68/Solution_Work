package com.training.facadepattern;

public class FacadeClient01 {
	public static void main(String[] args) {
		FacadeCar cars = new FacadeCar();
		cars.hatchBachDriver();
		cars.suvDriver();
		cars.sedanDriver();
	}
}
