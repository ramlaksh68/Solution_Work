package com.training.facadepattern;

public class FacadeCar {
	private HatchBack htchback;
	private Sedan sedan;
	private SUV suv;
	public FacadeCar() {
		super();
		this.htchback = new HatchBack();
		this.sedan = new Sedan();
		this.suv = new SUV();
	}
	
	public void hatchBachDriver() {
		htchback.drive();
	}
	public void suvDriver() {
		suv.drive();
	}
	public void sedanDriver() {
		sedan.drive();
	}
}
