package com.training.statergy;

import java.util.ArrayList;
import java.util.List;

import com.training.filter.Item;

public class ShoppingCard {
	private List<Item> item;
	ShoppingCard(){
		this.item=new ArrayList<>();
	}
	public void addItem(Item item)
	{
		this.item.add(item);
	}
	
	public void removeItem(Item item)
	{
		this.item.remove(item);
	}
	
	public void modeifyItem(Item itone)
	{
		for(Item it:item) {
			if(it.getItemCode().equals(itone.getItemCode())) {
				it=itone;
			}
		}
	}
	
	public int calculateTotal()
	{
		return item.stream().mapToInt(a->a.getPrice()*a.getQty()).sum();
	}
	public void checkOut(Payment payment) {
		item.stream().map(Item::getPrice).forEach(payment::pay);
	}
}
