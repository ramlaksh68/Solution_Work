package com.training.statergy;

public class CreditCard implements Payment {
	
	private String name;
	private String cardNumber;
	private String cvv;
	private String dateOfExpiry;
	private String bankName;
	private String discount;
	@Override
	public void pay(int amount) {
		if(bankName.equalsIgnoreCase("Hdfc")) {
			amount=(int)(amount-(amount*0.1));
			System.out.println("Paying with HDFC and got discound of 10%, paiod : "+amount);
		}
		else {
			System.out.println("Paid Amount "+amount+" with wallet : "+bankName);
			}
	}
	@Override
	public String toString() {
		return "CreditCard [name=" + name + ", cardNumber=" + cardNumber + ", cvv=" + cvv + ", dateOfExpiry="
				+ dateOfExpiry + ", bankName=" + bankName + ", discount=" + discount + "]";
	}
	public CreditCard(String name, String cardNumber, String cvv, String dateOfExpiry, String bankName,
			String discount) {
		super();
		this.name = name;
		this.cardNumber = cardNumber;
		this.cvv = cvv;
		this.dateOfExpiry = dateOfExpiry;
		this.bankName = bankName;
		this.discount = discount;
	}

}
