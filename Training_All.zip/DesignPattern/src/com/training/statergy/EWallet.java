package com.training.statergy;

public class EWallet implements Payment {
	private String email;
	private String password;
	private String walletName;
	
	@Override
	public void pay(int amount) {
		if(walletName.equalsIgnoreCase("paytm")) {
			amount=(int)(amount-(amount*0.1));
			System.out.println("Paying with PAYTM and got discound of 10%, paiod : "+amount);
		}
		else {
			System.out.println("Paid Amount "+amount+" with wallet : "+walletName);
			}
	}

	@Override
	public String toString() {
		return "EWallet [email=" + email + ", password=" + password + ", walletName=" + walletName + "]";
	}

	public EWallet(String email, String password, String walletName) {
		super();
		this.email = email;
		this.password = password;
		this.walletName = walletName;
	}

}
