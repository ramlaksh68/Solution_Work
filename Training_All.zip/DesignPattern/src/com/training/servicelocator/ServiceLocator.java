package com.training.servicelocator;

public class ServiceLocator {
	private static Caches cache;
	static {
		cache=new Caches();
	}
	public static Service getService(String jndiName) {
		Service service=cache.getService(jndiName);
		if(service!=null) {
			System.out.println("from Cache ..."+jndiName);
			return service;
		}
		InitialContext context=new InitialContext();
		Service serv=context.lookup(jndiName);
		cache.addService(serv);
		return serv;
	}
}
