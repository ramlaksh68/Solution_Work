package com.training.servicelocator;

public class DBService implements Service{

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return "DBService";
	}

	@Override
	public void excute() {
		// TODO Auto-generated method stub
		System.out.println("We are executing DB Service....");
	}

}
