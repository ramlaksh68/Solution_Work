package com.training.servicelocator;

public class ServiceClient {
	public static void main(String[] args) {

		ServiceLocator.getService("DBService").excute();
		ServiceLocator.getService("ERB Service").excute();

		ServiceLocator.getService("DBService").excute();
		ServiceLocator.getService("ERB Service").excute();

		ServiceLocator.getService("DBService").excute();
		ServiceLocator.getService("ERB Service").excute();
	}
}
