package com.training.servicelocator;

public class ERBService implements Service{

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return "ERB Service";
	}

	@Override
	public void excute() {
		// TODO Auto-generated method stub
		System.out.println("Executing ERB Service");
	}

}
