package com.training.abstractpattern;

public class FactoryProducers {
	
	//if this method is not made static the every time the instance is
	//created it is loaded in heap which would costly.
	//these kind of methods are called resources intensive
	public static AbstractFactory getFactory(String factoryName) {
		return factoryName.equals("vehicle")?new VechileFactory():factoryName.equals("color")?new ColorFactory():null;
	}
}
