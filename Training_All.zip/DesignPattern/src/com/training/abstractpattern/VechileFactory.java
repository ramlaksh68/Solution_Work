package com.training.abstractpattern;

public class VechileFactory extends AbstractFactory {

	@Override
	public IVehlcle getVehicle(String vehicle) {
		return vehicle.equals("car")?new Car():vehicle.equals("truck")?new Truck():null;
	}

	@Override
	public IColor getColor(String vehicle) {
		// TODO Auto-generated method stub
		return null;
	}

}
