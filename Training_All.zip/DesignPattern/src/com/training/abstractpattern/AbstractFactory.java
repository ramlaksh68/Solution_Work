package com.training.abstractpattern;

public abstract class AbstractFactory {
	//here you will have the list of factories to be exposed
	
	public abstract IVehlcle getVehicle(String vehicle);
	
	public abstract IColor getColor(String vehicle);
}



