package com.training.abstractpattern;

public class DesignPatternTest {
	
}
