package com.tarining;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.stream.Stream;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.MongoClient;
import com.mongodb.gridfs.GridFS;
import com.mongodb.gridfs.GridFSInputFile;

public class StoreImage {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  MongoClient mongoClient=new MongoClient();
		  DB db=mongoClient.getDB("exdb");
		  GridFS gridFS=new GridFS(db, "myimage");
		  
		  String srcPath="/Users/ramu.m/Desktop/sourceimg";
		  File srcFile=new File(srcPath);
		  Stream.of(srcFile.listFiles()).forEach((file)->{
			  InputStream is=null;
			try {
				is = new FileInputStream(file);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			  
			  GridFSInputFile picture=gridFS.createFile(is, file.getName());
			  
			  picture.setMetaData(new BasicDBObject("description","Image "+file.getName() +" store in target"));
			  picture.save();
		  });
		  
		  System.out.println("Saved in Db");
	}

}
