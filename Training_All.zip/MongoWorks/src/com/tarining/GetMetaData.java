package com.tarining;
import static java.lang.System.*;
import com.mongodb.MongoClient;

public class GetMetaData {
	static MongoClient mongoClient=new MongoClient();
	
	public static void main(String[] args) {
		// localhost port :27017
		
		out.println("Connection Got to "+mongoClient);	
		
		out.println("List of DBS from Mongo");
		
		mongoClient.getDatabaseNames().forEach(GetMetaData::getCollectionName);
	}

	
	
	public static void getCollectionName(String dbname) {
		out.println("-------------"+dbname+"-------------");
		mongoClient.getDB(dbname).getCollectionNames().forEach(out::println);
	}
}
