package com.tarining;

import static java.lang.System.out;

import java.util.HashMap;
import java.util.Map;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;

public class GetQueryData {
	static  MongoClient mongoClient=new MongoClient();
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 DB db=mongoClient.getDB("exdb");
		 DBCollection dbCollection=db.getCollection("emps");
		 
		 
		 //if you wnt multiple condotion
		 DBObject quryCondition=new BasicDBObject("empsalary", null);
		 DBObject sortCondition=new BasicDBObject("empname", -1);
		 Map<String,Integer> proList=new HashMap<>();
		 proList.put("empnm", 1);
		 proList.put("_id", 0);
		 DBObject proCondition=new BasicDBObject(proList);
		 
		 ///where empid eq 105
		 dbCollection.find(quryCondition,proCondition).sort(sortCondition).limit(2).forEach(out::println);
		 
		 
		 
		 
	}

	
}
