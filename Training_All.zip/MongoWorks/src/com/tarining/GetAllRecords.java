package com.tarining;
import static java.lang.System.*;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;

public class GetAllRecords {
	static  MongoClient mongoClient=new MongoClient();
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 DB db=mongoClient.getDB("exdb");
		 DBCollection dbCollection=db.getCollection("emps");
		 
		 dbCollection.find().forEach(GetAllRecords::getCollectionName);
	}

	
	public static void getCollectionName(DBObject dbCursor) {
		out.println("empid : "+dbCursor.get("empid"));
		out.println("empnm : "+dbCursor.get("empnm"));
		out.println("empsal : "+dbCursor.get("empsalary"));
		out.println("--------------------");
	}
}
