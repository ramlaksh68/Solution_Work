package com.tarining;
import static java.lang.System.*;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;

public class GetOneRecord {
	public static void main(String[] args) {
		 MongoClient mongoClient=new MongoClient();
		 
		 DB db=mongoClient.getDB("exdb");
		 DBCollection dbCollection=db.getCollection("emps");
		 
		 DBObject dbObject=dbCollection.findOne();
		 
		 out.println("Whole Object="+dbObject);
		 out.println(" Object Proprety of Emp.Name="+dbObject.get("empnm"));
	}
}
