package com.tarining;

import java.io.Serializable;

import com.mongodb.BasicDBObject;

public class Employee extends BasicDBObject {

		private int empid;
		private String empnm;
		private String empemail;
		private Double empsalary;
		@Override
		public String toString() {
			return "Employee [empid=" + empid + ", empnm=" + empnm + ", empemail=" + empemail + ", empsalary="
					+ empsalary + "]";
		}
		
		public Employee() {};
		public Employee(int empid, String empnm, Double empsalary, String empemail) {
			super();
			this.empid = empid;
			this.empnm = empnm;
			this.empemail = empemail;
			this.empsalary = empsalary;
			this.put("empid", empid);
			this.put("empnm", empnm);
			this.put("empemail", empemail);
			this.put("empsalary", empsalary);
		}
		public int getEmpid() {
			return empid;
		}
		public void setEmpid(int empid) {
			this.empid = empid;
		}
		public String getEmpnm() {
			return empnm;
		}
		public void setEmpnm(String empnm) {
			this.empnm = empnm;
		}
		public String getEmpemail() {
			return empemail;
		}
		public void setEmpemail(String empemail) {
			this.empemail = empemail;
		}
		public Double getEmpsalary() {
			return empsalary;
		}
		public void setEmpsalary(Double empsalary) {
			this.empsalary = empsalary;
		}
		
	
}
