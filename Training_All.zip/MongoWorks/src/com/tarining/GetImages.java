package com.tarining;

import java.io.IOException;
import java.util.List;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.MongoClient;
import com.mongodb.gridfs.GridFS;
import com.mongodb.gridfs.GridFSDBFile;

public class GetImages {

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
		  MongoClient mongoClient=new MongoClient();
		  DB db=mongoClient.getDB("exdb");
		  String trgtPath="/Users/ramu.m/Desktop/targetimg/";
		  
		  GridFS gridFS=new GridFS(db, "myimage");
		  
		  List<GridFSDBFile> list=gridFS.find(new BasicDBObject());
		  
		  list.forEach((file)->{
			  try {
				file.writeTo(trgtPath+file.getFilename());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  });
		  System.out.println("Restored Images From MongoDb");
	}

}
