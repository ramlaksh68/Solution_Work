package com.training.aop.model;

import org.springframework.beans.factory.annotation.Autowired;

public class SBAccount {
	
	private Account account;

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	public Double showBalance() {
		return account.getBalance();
	}
	
	@Override
	public String toString() {
		return "SBAccount [account=" + account + "]";
	}
	
}
