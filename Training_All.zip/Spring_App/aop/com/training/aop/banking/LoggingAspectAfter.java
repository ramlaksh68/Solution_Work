package com.training.aop.banking;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;

@Aspect
public class LoggingAspectAfter {

	@After("execution(* get*())")
	public void afterGetter() {
		System.out.println("________ After Advice Worked _________");
	}
	
	
	@AfterReturning("execution(* get*())")
	public void afterReturningGetter() {
		System.out.println("________ After Returning Suuccessfully Advice Worked _________");
	}
	
	
	@AfterReturning(pointcut="args(val)",returning="returnString")
	public void afterReturningStringSetteretter(String val,String returnString) {
		System.out.printf("input is '%s' and output is '%s'",val,returnString );
	}
	
	

	@AfterThrowing(pointcut="execution(* get*())",throwing="ex")
	public void afterThrowingError(Exception ex) {
		System.out.printf("After Exception = ",ex.getMessage() );
	}
	
	
	
}
