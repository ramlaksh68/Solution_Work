package com.training.aop.banking;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class LoggingAspect {

	//this is specify method excatly but this will find in any class
	//@Before("execution(public Double getBalance())")
	//this is fully qualified named
	//@Before("execution(public * com.training.aop.model.CAAccount.showBalance())")
	//this is regex filter
	//@Before("execution(public * *())")
	//this is one or more arguments filter
	@Before("allGetters()")
	public void beforeloggingInfo() {
		System.out.println("***********Only getters Before Logging Is Done*******");
	}
	
	
	@Before("allSetters()")
	public void secondAdvice() {
		System.out.println("***********Only setters Before Logging Is Done*******");
	}
	
	
	@Before("allGetters()||allSetters()")
	public void compundAdvice() {
		System.out.println("***********Both Setter and Getter Method *******");
	}
	
	@Pointcut("execution(public * get*())")
	public void allGetters() {
		System.out.println("***********DONT DISPLAY*******");
	}
	
	
	@Pointcut("execution(public * set*())")
	public void allSetters() {
		System.out.println("***********DONT DISPLAY*******");
	}
}
