package com.training.basics;

import java.io.Serializable;

public interface HelloService {

	
	public String sayHello() ;
	
	public String sayHello(String name,String city) ;
}
