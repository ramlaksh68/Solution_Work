package com.training.basics;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.training.employee.Employee;

public class MainApp {

	public static void main(String[] args) {
		//BeanFactory factory=new XmlBeanFactory(new ClassPathResource("spring-app.xml")); // by BeanFactory
		AbstractApplicationContext factory=new ClassPathXmlApplicationContext("spring-app.xml","spring-app2.xml"); // by ApplicationContext
		HelloService service=factory.getBean("defaultHello",HelloService.class);
		Employee service1=factory.getBean("employee",Employee.class);
		System.out.println(service.sayHello());
		System.out.println(service1);
		factory.registerShutdownHook();
	}  

}
