package com.training.bpp;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;

import com.training.employee.Employee;

// if we want to know this is post processor
// implements bean postproessor this way every bean wen create by spring hasto go through tis class
// since this class can handle any class all r=are given as on object

public class EMployeeBeanProcessor implements BeanPostProcessor{

	@Override
	public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
		// TODO Auto-generated method stub
		System.out.println("**********this is implementation init method of "+beanName.toUpperCase()+"***********");
		if(bean instanceof Employee) {
			Employee emp=(Employee)bean;
			emp.setEmpnm(emp.getEmpnm().toUpperCase());
			return emp;
		}
		return bean;
	}

	@Override
	public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
		// TODO Auto-generated method stub
		System.out.println("************this is implementation destroy method of "+beanName.toUpperCase()+"**********");
		return bean;
	}

}
