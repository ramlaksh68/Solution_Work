/**
		 * @see will introduce Profile in spring with annontaion and 
		 * make diffrenet set of beans or confguratuon avaiabale conditionally
		 * 
		 * 
		 * 
		 * for ecxample aasume dev -orcale testing -mysql qc -sqlsever
		 */
		package com.training.profile;
		
		/**
		 * @author ramu.m
		 *
		 */
		
