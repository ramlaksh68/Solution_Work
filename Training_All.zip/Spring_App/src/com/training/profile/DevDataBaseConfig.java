package com.training.profile;

import javax.activation.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
@Configuration
@Profile("Developement")

public class DevDataBaseConfig implements DataBaseConfig {

	@Override
	@Bean(name="dataSource")
	public DataSource createDataSource() {
		System.out.println("Creating Developement Db Instance");
		
		//		you can set parameter
		
		return null;
	}



}
