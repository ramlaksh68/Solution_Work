package com.training.employee;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {

	public static void main(String[] args) {
		AbstractApplicationContext factory=new ClassPathXmlApplicationContext("spring-app2.xml"); // by ApplicationContext
		System.out.println("----------------------------------");
		Employee emp=factory.getBean("employee",Employee.class);
		System.out.println(emp);
		System.out.println("----------------------------------");
		Employee emp1=factory.getBean("employee",Employee.class);
		System.out.println(emp);
		System.out.println("----------------------------------");
		if(emp.equals(emp1))										 // by ApplicationContext
		System.out.println(" Scope is Singleton  ");
		else
		System.out.println("Scope is Prototype ");
		System.out.println("----------------------------------");
		
		factory.registerShutdownHook();
	}
}
