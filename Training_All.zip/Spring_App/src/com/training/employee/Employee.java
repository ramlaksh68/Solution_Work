package com.training.employee;

public class Employee {
	private int empid;
	private String empnm;
	private Double empsalry;
	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", empnm=" + empnm + ", empsalry=" + empsalry + "]";
	}
	public Employee(int empid, String empnm, Double empsalry) {
		super();
		this.empid = empid;
		this.empnm = empnm;
		this.empsalry = empsalry;
	}
	public Employee() {
		System.out.println("Default Constructor is Invoking for Employee.....");
	}
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEmpnm() {
		return empnm;
	}
	public void setEmpnm(String empnm) {
		this.empnm = empnm;
	}
	public Double getEmpsalry() {
		return empsalry;
	}
	public void setEmpsalry(Double empsalry) {
		this.empsalry = empsalry;
	}
	
	
	public void init() {
		System.out.println("Init for Emloyees");
	}
	
	
	public void destroy() {
		System.out.println("Destroy for Employes");
	}
	
	
	

	public void ginit() {
		System.out.println("Init for Global Employee");
	}
	
	
	public void gdestroy() {
		System.out.println("Destroy for Global Employee");
	}
}
