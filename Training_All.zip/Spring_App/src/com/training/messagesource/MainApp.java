package com.training.messagesource;

import java.util.Locale;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {
 public static void main(String[] args) {
	 ApplicationContext factory=new ClassPathXmlApplicationContext("spring-message-resource.xml");
	 HelloWorld hello=factory.getBean("helloworld",HelloWorld.class);
	 String engMorning=factory.getMessage("goodmorning", new Object[] {},null);
	 String frMorning=factory.getMessage("goodmorning", new Object[] {},new Locale("FR"));
	 String tmlMorning=factory.getMessage("goodmorning", new Object[] {},new Locale("TML"));
	 System.out.println(engMorning);
	 System.out.println(frMorning);
	 System.out.println(tmlMorning);
	 System.out.println("*********************");
	 hello.sayHello();
	 hello.sayHello_Fr();
	 hello.sayHello_Tml();
}
}
