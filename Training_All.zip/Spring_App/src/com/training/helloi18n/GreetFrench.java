package com.training.helloi18n;

public class GreetFrench implements Greeting {

	@Override
	public String greetHello() {
		// TODO Auto-generated method stub
		return "Bonjur tout le monde";
	}

}
