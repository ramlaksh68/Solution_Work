package com.training.helloi18n;

public interface Greeting {
 String greetHello();
}
