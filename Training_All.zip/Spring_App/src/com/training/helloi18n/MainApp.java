package com.training.helloi18n;

import java.util.stream.Stream;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MainApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext factory=new AnnotationConfigApplicationContext(Configuration_App.class); // by ApplicationContext
		Stream.of(factory.getBean("english",Greeting.class),factory.getBean("french",Greeting.class))
		.map(obj->obj.greetHello()).forEach(System.out::println);

	}

}
