package com.training.autowired;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Speaker {
	@Value("${speaker.type}")
	private String type;
	@Value("${speaker.voloLevels}")
	private int voloLevels;
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getVoloLevels() {
		return voloLevels;
	}
	public void setVoloLevels(int voloLevels) {
		this.voloLevels = voloLevels;
	}
	@Override
	public String toString() {
		return "Speaker [type=" + type + ", voloLevels=" + voloLevels + "]";
	}
	public Speaker() {
		System.out.println("creating speaker "+this);
	}
	public Speaker(String type, int voloLevels) {
		super();
		this.type = type;
		this.voloLevels = voloLevels;
	}
	
}
