package com.training.entity;

public class Employee {
	private int empid;
	private String empnm;
	private double empsalary;

	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public String getEmpnm() {
		return empnm;
	}

	public void setEmpnm(String empnm) {
		this.empnm = empnm;
	}

	public double getEmpsalary() {
		return empsalary;
	}

	public void setEmpsalary(double empsalary) {
		this.empsalary = empsalary;
	}

	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", empnm=" + empnm + ", empsalary=" + empsalary + "]";
	}

	public Employee(int empid, String empnm, double empsalary) {
		super();
		this.empid = empid;
		this.empnm = empnm;
		this.empsalary = empsalary;
	}

	public Employee() {
	}
}
