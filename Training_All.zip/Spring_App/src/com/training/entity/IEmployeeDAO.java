package com.training.entity;

import java.util.List;

import javax.sql.DataSource;

public interface IEmployeeDAO {
	
	Employee getEmployee(int empid);

	List<Employee> getAllEmpList();

	void insertEmployye(Employee emp);

	void updateEmployee(Employee employee);

	void setDataSource(DataSource dataSource);
}
