package com.training.collections;

import java.util.Set;

public class AddressSet {
	Set<String> address;

	public Set<String> getAddress() {
		return address;
	}

	public void setAddress(Set<String> address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "AddressSet [address=" + address + "]";
	}
	
}
