package com.training.exilant.Entity;

public class HelloWorld {
	private String message;
	public HelloWorld(String string) {
		this.message=string;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}

}
