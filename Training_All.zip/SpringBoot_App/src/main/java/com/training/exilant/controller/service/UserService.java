package com.training.exilant.controller.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static java.util.stream.Collectors.*;
import java.util.stream.Stream;

import org.springframework.stereotype.Service;

import com.training.exilant.Entity.User;

@Service
public class UserService {
	//we are simulationg th db
	//it is the list
	private static List<User> userList=null;
	private static int userCount=4000;
	static {
		userList=Stream.of(
				new User(1234, "Ramu", "10/03/1995"),
				new User(8986, "Siva", "10/03/1993"),
				new User(6786, "Raja", "10/03/1997"),
				new User(2344, "Laksh", "10/03/1995")
				).collect(toList());
	}
	
	
	public List<User> getAllUserList(){
		return userList;
	}
	
	
	public User saveUser(User user){
		if(user.getUserid()==null)
			user.setUserid(++userCount);
		userList.add(user);
		return user;
	}
	
	public List<User> deleteUser(Integer id){
		User userObj=userList.stream().filter(user->user.getUserid().equals(id)).findFirst().get();
		userList.remove(userObj);
		return userList;
	}
	
	
	public List<User> updateUser(User updateuser,Integer id){
		User userObj=userList.stream().filter(user->user.getUserid().equals(id)).findFirst().get();
		userList.remove(userObj);
		userList.add(updateuser);
		return userList;
	}


	public User getOneUser(Integer id) {
		Optional<User> opt=userList.stream().filter(user->user.getUserid().equals(id)).findFirst();
		return 	opt.isPresent()?opt.get():null;
	}
	
}
