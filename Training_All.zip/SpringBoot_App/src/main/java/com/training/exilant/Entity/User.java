package com.training.exilant.Entity;

public class User {
	private Integer userid;
	private String username;
	private String birthdate;
	public Integer getUserid() {
		return userid;
	}
	public void setUserid(Integer userid) {
		this.userid = userid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getBirthdate() {
		return birthdate;
	}
	public void setBirthdate(String birthdate) {
		this.birthdate = birthdate;
	}
	@Override
	public String toString() {
		return "User [userid=" + userid + ", username=" + username + ", birthdate=" + birthdate + "]";
	}
	public User() {}
	public User(Integer userid, String username, String birthdate) {
		super();
		this.userid = userid;
		this.username = username;
		this.birthdate = birthdate;
	}
	
}
