
import org.apache.catalina.core.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableAsync;

import services.MessageService;

@ComponentScan
@EnableAsync
public class Main_App {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext app=new AnnotationConfigApplicationContext(Main_App.class);
		MessageService msgService=app.getBean("MessageService",MessageService.class);
		msgService.sendMessage("Hi Ramu");
	}

}
